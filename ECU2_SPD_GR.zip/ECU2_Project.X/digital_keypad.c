#include <xc.h>
#include "digital_keypad.h"

void init_digital_keypad(void)
{
	TRISC = TRISC | INPUT_PINS;
}

unsigned char read_digital_keypad(int choice)
{
	if(choice == 1)
    {
        return PORTC & 0x0F;
    }
    else if(choice == 0)
    {
        static int count = 0;
        if(((PORTC & 0x0F) != 0x0F) && count == 0)
        {
            count = 1;
            return PORTC & 0x0F;
        }
        else if((PORTC & 0x0F) == 0x0F)
        {
            count = 0;
        }
    }
    return 0x0F;
}