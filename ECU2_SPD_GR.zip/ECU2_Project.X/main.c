/*
 Name : Prashanth Reddy
 * date : 17-04-2026
 * project : CAN automotive dashboard - ECU2 using CAN protocol
 * TITLE : ECU2 speed and gear
 * description :
 * ECU2 is responsible for acquiring vehicle speed and gear position data
 * and transmitting this information over the CAN bus to other ECUs
 * in the automotive dashboard system. The ECU processes input signals,
 * formats CAN messages, and ensures real-time data transmission for
 * accurate dashboard indication.
 */

#include <xc.h>
#include <stdlib.h>
#include "adc.h"
#include "can.h"
#include "ecu1_sensor.h"
#include "msg_id.h"
#include "digital_keypad.h"

void init_config()
{
    init_adc();          // Initialize ADC for speed sensing
    init_can();          // Initialize CAN module
    init_digital_keypad();          // Initialize digital keypad for gear input
}


int main(void)
{
    init_config();       // Call initialization function

    unsigned char speed_array[3];   // CAN transmit buffer for speed
    unsigned char gear_array[1];    // CAN transmit buffer for gear
    
    uint16_t speed_msg_id = SPEED_MSG_ID;   // Speed mdg id backup;
    uint16_t gear_msg_id = GEAR_MSG_ID;     // gear mdg id backup;
    uint16_t speed;
    GearState gear_status;      // Variable to store gear status

    
    while(1)
    {
          
        //Call the functions
        speed = get_speed();
        gear_status = get_gear_pos();
        
        if(gear_status == GEAR_NEUTRAL)
        {
            speed=0;
        }
        
         /* Convert speed value to ASCII characters */
        speed_array[0] = speed / 100 + '0';        // Hundreds place
        speed_array[1] = (speed / 10) % 10 + '0';  // Tens place
        speed_array[2] = speed % 10 + '0';         // Units place
        
        /* Store gear status */
        gear_array[0] = gear_status; // Gear value
        
        can_transmit(SPEED_MSG_ID,speed_array, 3);        
        can_transmit(GEAR_MSG_ID,gear_array, 1);
    }
}