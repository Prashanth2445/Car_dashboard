#include "ecu1_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"

uint16_t get_speed()
{   
    // Implement the speed function
    unsigned short adc_val=0;
    
    // Read ADC value and scale it to speed range
    adc_val = (read_adc(SPEED_ADC_CHANNEL) / 10.23);
    return adc_val;
}

unsigned int get_gear_pos(void)
{
    static GearState gear = GEAR_NEUTRAL; // Store last gear state

    char key;
    
    key= read_digital_keypad(0);     // Read keypad input
    
    // Implement the gear function
    
    // Increase gear when SW1 is pressed
    if(key == SWITCH1)      // Gear up
    {
        if(MAX_GEAR > gear)    // Check upper gear limit
        {
            gear++;        // Increment gear
        }
    }
    // Decrease gear when SWITCH2 is pressed
    else if(key == SWITCH2)     // Gear down
    {
        if( 0 < gear)  // Check lower gear limit
        {
            gear--;    // Decrement gear
        }
    }
    return gear;   // Return current gear state
}