#include <xc.h>
#include "message_handler.h"

void __interrupt() isr(void)
{
	static unsigned short count = 0;
     
	if (TMR0IF)
	{
		TMR0 = TMR0 + 8;

		if (count++ == 5000)
		{
			count = 0;
            led_state = led_state ^ 1;
		}
		TMR0IF = 0;
	}
}
