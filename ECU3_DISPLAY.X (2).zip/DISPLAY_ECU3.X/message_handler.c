

#include "message_handler.h"
#include "msg_id.h"
#include "can.h"
#include "clcd.h"
#include<string.h>


volatile unsigned char led_state = e_ind_off; // LED blink state for indicators

/* Handle received speed data */
void handle_speed_data(uint8_t *data, uint8_t len)
{
    char buf[3];                         // Buffer to store speed string

    memcpy(buf, data, len);              // Copy received CAN data
    buf[len] = '\0';                     // Null terminate string
    //buf[len-1]='\0';

    clcd_print("SP", LINE1(5));          // Display label
    clcd_print(buf, LINE2(5));            // Display speed value
}

/* Handle received gear data */
void handle_gear_data(uint8_t *data, uint8_t len) 
{
    char gear_str[3];                    // Buffer for gear display

    // Decode gear value
    switch (data[0])
    {
        case GEAR_NEUTRAL:  gear_str[0] = 'N'; gear_str[1] = ' '; break;
        case GEAR_1:        gear_str[0] = '1'; gear_str[1] = ' '; break;
        case GEAR_2:        gear_str[0] = '2'; gear_str[1] = ' '; break;
        case GEAR_3:        gear_str[0] = '3'; gear_str[1] = ' '; break;
        case GEAR_4:        gear_str[0] = '4'; gear_str[1] = ' '; break;
        case GEAR_5:        gear_str[0] = '5'; gear_str[1] = ' '; break;
        case GEAR_REVERSE:  gear_str[0] = 'R'; gear_str[1] = ' '; break;
    }

    gear_str[2] = '\0';                  // Null terminate string

    clcd_print("GR", LINE1(9));           // Display label
    clcd_print(gear_str, LINE2(9));       // Display gear value
}

/* Handle received RPM data */
void handle_rpm_data(uint8_t *data, uint8_t len) 
{
    char buf[8];                         // Buffer to store RPM string

    memcpy(buf, data, len);              // Copy received CAN data
    buf[len] = '\0';                     // Null terminate string

    clcd_print("RPM", LINE1(0));          // Display label
    clcd_print(buf, LINE2(0));            // Display RPM value
}

/* Handle received indicator data */
void handle_indicator_data(uint8_t *data, uint8_t len) 
{
    char ind_str[3];

    switch (data[0])
    {
        case e_ind_left:
            ind_str[0] = '<'; ind_str[1] = '-';
            if (led_state) 
                LEFT_IND_ON();
            else 
                LEFT_IND_OFF();
            RIGHT_IND_OFF();
            break;

        case e_ind_right:
            ind_str[0] = '-'; ind_str[1] = '>';
            if (led_state) 
                RIGHT_IND_ON();
            else 
                RIGHT_IND_OFF();
            LEFT_IND_OFF();
            break;

        case e_ind_hazard:
            ind_str[0] = '<'; ind_str[1] = '>';
            if (led_state)
            {
                LEFT_IND_ON();
                RIGHT_IND_ON();
            }
            else
            {
                LEFT_IND_OFF();
                RIGHT_IND_OFF();
            }
            break;

        default:
            ind_str[0] = '-'; ind_str[1] = '-';
            LEFT_IND_OFF();
            RIGHT_IND_OFF();
            break;
    }

    ind_str[2] = '\0';

    clcd_print("IND", LINE1(12));
    clcd_print(ind_str, LINE2(12));
}

/* Process received CAN bus data */
void process_canbus_data() 
{   
    uint8_t rx_data[8];                  // CAN receive buffer
    uint16_t rx_id;                      // Received CAN message ID
    uint8_t rx_len;                      // Length of received data

    can_receive(&rx_id, rx_data, &rx_len); // Receive CAN message

    if (rx_len > 0)                      // Check if valid data received
    {
        switch (rx_id)
        {
            case SPEED_MSG_ID:      handle_speed_data(rx_data, rx_len); break;
            case GEAR_MSG_ID:       handle_gear_data(rx_data, rx_len); break;
            case RPM_MSG_ID:        handle_rpm_data(rx_data, rx_len); break;
            case INDICATOR_MSG_ID:  handle_indicator_data(rx_data, rx_len); break;
        }
    }
}
