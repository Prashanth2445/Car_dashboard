/*
 * Name        : Prashanth Reddy
 * Date        : 17-04-2026
 * Project     : CAN Automotive Dashboard - ECU3 Using CAN Protocol
 * Title       : ECU3 Dashboard Display
 *
 * Description :
 * ECU3 functions as the dashboard unit in the CAN automotive system.
 * It receives CAN data from ECU1 and ECU2, including vehicle speed,
 * gear position, RPM, and indicator status. Based on the received
 * messages, ECU3 updates the dashboard displays and indicators
 * accordingly, providing real-time vehicle information to the user.
 */


#include "message_handler.h"
#include "can.h"
#include "clcd.h"
#include "msg_id.h"
#include "timer0.h"

void init_config(void) {
    // Initialize CLCD and CANBUS
    init_clcd();
    TRISB = 0x08; // Set RB2 as output, RB3 as input, remaining as output for can
    PORTB = 0x00;
    init_can();
    // Enable Interrupts
    PEIE = 1;
    GIE = 1;
    init_timer0();
}

void main(void) {
    // Initialize peripherals
    init_config();

    /* ECU3 main loop */
    while (1) {
        // Read CAN Bus
        process_canbus_data();
    }

    return;
}
