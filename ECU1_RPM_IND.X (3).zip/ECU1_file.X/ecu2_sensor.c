#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "main.h"
#include "digital_keypad.h"

uint16_t get_rpm()
{
    //Implement the rpm function
    unsigned short adc_val=0;
    
    adc_val = ((read_adc(RPM_ADC_CHANNEL)/10.23)* 60);
    
    return adc_val;
}

uint16_t get_engine_temp()
{
    return 0; 
}

IndicatorStatus process_indicator(void)
{
    static char prev = 0x0F;    // Store last valid key (default: no key)
    
    char key;
    key= read_digital_keypad(LEVEL); // Read digital keypad input  //read_switches

    if (key != 0x0F)
        prev = key;
    
    if(prev == SWITCH1)     // Right indicator
    {
        return e_ind_right;
    }
    else if(prev == SWITCH2)    // Left indicator
    {
        return e_ind_left;
    }
    else if(prev == SWITCH3)       // Hazard indicator
    {
        return e_ind_hazard;
    }
    else if(prev == SWITCH4)    // Indicator OFF
    {
        return e_ind_off;
    }
}