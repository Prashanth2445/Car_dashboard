/*
 Name : Prashanth Reddy
 * date : 17-04-2026
 * project : CAN automotive dashboard - ECU1 using CAN protocol
 * TITLE : ECU1 indicators and RPM.
 * description :
 * ECU1 is responsible for processing vehicle indicator status and
 * engine RPM information. It receives relevant control data, updates
 * indicator states, and transmits RPM and indicator status messages
 * over the CAN bus to ECU3 (Dashboard). This ensures accurate and
 * real-time display of indicators and RPM on the dashboard.
 */


#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "main.h"
#include "digital_keypad.h"

#define _XTAL_FREQ 20000000  // System clock frequency (20 MHz)

void init_config()
{
    init_adc();
    init_can();
    init_digital_keypad();
}

int main()
{
    //call the functions    
    init_config();
    //static unsigned short indicater=0;
    uint16_t rpm;
    IndicatorStatus ind_status; // Variable to store indicator status
    
    uint16_t indi_msg_id = INDICATOR_MSG_ID;
    uint16_t rpm_msg_id = RPM_MSG_ID;
    
    uint8_t indicater_array[1];
    uint8_t rpm_array[4];
    
    while(1)
    {   
        //Call the functions
        rpm = get_rpm();
        ind_status = process_indicator();
         
         /* Convert RPM value into ASCII characters */
        rpm_array[0] = rpm / 1000 + '0';        // Thousands place
        rpm_array[1] = (rpm / 100) % 10 + '0';  // Hundreds place
        rpm_array[2] = (rpm / 10) % 10 + '0';   // Tens place
        rpm_array[3] = rpm % 10 + '0';          // Units place
        
        /* Store indicator status */
        indicater_array[0] = ind_status;   // Indicator ON/OFF status
        
        can_transmit(RPM_MSG_ID, rpm_array,4);
        can_transmit(INDICATOR_MSG_ID, indicater_array,1);
    }
}
