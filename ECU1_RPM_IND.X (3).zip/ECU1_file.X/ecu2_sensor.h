#ifndef ECU2_SENSOR_H
#define	ECU2_SENSOR_H

#include <stdint.h>
//#include "digital_keypad.h"
#include <xc.h>

#define RPM_ADC_CHANNEL 0x04
#define ENG_TEMP_ADC_CHANNEL 0x06

#define LED_OFF 0
#define LED_ON 1

typedef enum {
    e_ind_off,
    e_ind_left,
    e_ind_right,
    e_ind_hazard
} IndicatorStatus;

extern volatile IndicatorStatus prev_ind_status, cur_ind_status;
extern volatile unsigned char led_state;

unsigned short get_rpm();
uint16_t get_engine_temp();
IndicatorStatus process_indicator();
void update_indicator(void);
void my_itoa(uint16_t num, char str[]);
unsigned char my_strlen(const char *str);


#endif	/* ECU1_SENSOR_H */

